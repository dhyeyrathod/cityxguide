<script type="text/javascript">
	var base_url = '<?= base_url() ?>';
</script>
<script src="<?= base_url('assets') ?>/js/jquery-3.2.1.min.js"></script>
<script src="<?= base_url('assets') ?>/js/popper.min.js"></script>
<script src="<?= base_url('assets') ?>/js/bootstrap.min.js"></script>
<script src="<?= base_url('assets') ?>/js/main.js"></script>
<script src="<?= base_url('assets') ?>/js/plugins/pace.min.js"></script>
<script type="text/javascript" src="<?= base_url('assets') ?>/js/plugins/chart.js"></script>
<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>