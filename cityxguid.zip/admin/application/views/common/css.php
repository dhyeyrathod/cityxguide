<!-- Main CSS-->
<link rel="stylesheet" type="text/css" href="<?= base_url('assets') ?>/css/main.css">
<!-- Font-icon css-->
<link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">